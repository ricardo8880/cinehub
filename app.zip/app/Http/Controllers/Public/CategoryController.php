<?php

namespace App\Http\Controllers\Public;

use App\Support\EnglishGroup;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\CategoryLocalization;
use App\Models\Post;
use App\Support\PublicPostPresenter;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CategoryController extends Controller
{
    public function __invoke(Request $request, string $locale, string $category, PublicPostPresenter $presenter): View
    {
        $categoryLocalization = CategoryLocalization::query()
            ->where('locale', $locale)
            ->where('slug', $category)
            ->where('is_active', true)
            ->with('category')
            ->firstOrFail();

        $categoryModel = $categoryLocalization->category;
        abort_unless($categoryModel->is_active, 404);

        $genres = $categoryModel->genres()
            ->where('genres.is_active', true)
            ->orderBy('genres.sort_order')
            ->with(['localizations' => fn ($query) => $query->where('locale', $locale)->where('is_active', true)])
            ->orderBy('genres.sort_order')
            ->orderBy('genres.id')
            ->get()
            ->filter(fn ($genre) => $genre->localization($locale))
            ->values();

        $selectedGenre = null;
        $selectedGenreSlug = $request->string('genre')->lower()->value();

        if ($selectedGenreSlug !== '') {
            $selectedGenre = $genres->first(fn ($genre) => $genre->localization($locale)?->slug === $selectedGenreSlug);
            abort_unless($selectedGenre, 404);
            $selectedGenre->load('localizations');
        }

        $navigationCategories = Category::query()
            ->where('is_active', true)
            ->whereHas('localizations', fn (Builder $q) => $q->where('locale', $locale)->where('is_active', true))
            ->with(['localizations' => fn ($q) => $q->where('locale', $locale)->where('is_active', true)])
            ->orderBy('sort_order')->orderBy('id')->get();

        $posts = Post::query()
            ->published()
            ->where('publication_type', 'standard')
            ->whereHas('categories', fn ($query) => $query->whereKey($categoryModel->id))
            ->when($selectedGenre, fn ($query) => $query->whereHas('genres', fn ($genreQuery) => $genreQuery->whereKey($selectedGenre->id)))
            ->whereHas('localizations', fn ($query) => $query->where('locale', $locale)->where('is_active', true))
            ->whereHas('media', fn ($query) => $query->where('locale', $locale)->whereIn('type', ['image', 'trailer']))
            ->with([
                'categories' => fn ($query) => $query->where('is_active', true)->with(['localizations' => fn ($lq) => $lq->where('locale', $locale)->where('is_active', true)])->orderBy('sort_order'),
                'localizations' => fn ($query) => $query->where('locale', $locale)->where('is_active', true),
                'media' => fn ($query) => $query->where('locale', $locale),
            ])
            ->withCount([
                'reactions as likes_count' => fn ($query) => $query->whereIn('locale', EnglishGroup::history($locale))->where('type', 'like'),
                'comments as approved_comments_count' => fn ($query) => $query->whereIn('locale', EnglishGroup::history($locale))->where('status', 'approved'),
            ])
            ->withSum(['views as views_count' => fn ($q) => $q->whereIn('locale', EnglishGroup::history($locale))], 'view_count')
            ->latest('published_at')->paginate(12)->withQueryString();

        abort_if($posts->currentPage() > max(1, $posts->lastPage()), 404);

        $posts->setCollection($posts->getCollection()->map(fn (Post $post) => $presenter->card($post, $locale))->filter()->values());

        $currentPage = $posts->currentPage();
        $currentGenreLocalization = $selectedGenre?->localization($locale);
        $canonicalParameters = [
            'locale' => $locale,
            'category' => $categoryLocalization->slug,
        ];

        if ($currentGenreLocalization) {
            $canonicalParameters['genre'] = $currentGenreLocalization->slug;
        }

        if ($currentPage > 1) {
            $canonicalParameters['page'] = $currentPage;
        }

        $canonicalUrl = route('categories.show', $canonicalParameters);
        $localeLinks = [];
        $alternateUrls = [];
        $categoryModel->loadMissing('localizations');

        foreach (array_keys(config('localization.locales', [])) as $routeLocale) {
            // Filtered or paginated archives can represent a different set of
            // posts in every language; don't publish misleading hreflang pairs.
            if ($currentPage > 1) {
                break;
            }

            $version = $categoryModel->localization($routeLocale);
            $genreVersion = $selectedGenre?->localization($routeLocale);

            $hasVisiblePosts = $categoryModel->posts()
                ->published()
                ->where('publication_type', 'standard')
                ->whereHas('localizations', fn (Builder $query) => $query->where('locale', $routeLocale)->where('is_active', true))
                ->whereHas('media', fn (Builder $query) => $query->where('locale', $routeLocale)->whereIn('type', ['image', 'trailer']))
                ->when($selectedGenre, fn (Builder $query) => $query->whereHas('genres', fn (Builder $genreQuery) => $genreQuery->whereKey($selectedGenre->id)))
                ->exists();

            if (! $version || ($selectedGenre && ! $genreVersion) || ! $hasVisiblePosts) {
                $localeLinks[$routeLocale] = null;
                continue;
            }

            $parameters = [
                'locale' => $routeLocale,
                'category' => $version->slug,
            ];

            if ($genreVersion) {
                $parameters['genre'] = $genreVersion->slug;
            }

            if ($currentPage > 1) {
                $parameters['page'] = $currentPage;
            }

            $url = route('categories.show', $parameters);
            $localeLinks[$routeLocale] = $url;
            if (\App\Support\Seo::indexable($routeLocale)) {
                $alternateUrls[$routeLocale] = $url;
            }
        }

        return view('public.category', [
            'category' => $categoryModel,
            'categoryLocalization' => $categoryLocalization,
            'genres' => $genres,
            'selectedGenre' => $selectedGenre,
            'posts' => $posts,
            'navigationCategories' => $navigationCategories,
            'localeLinks' => $localeLinks,
            'alternateUrls' => $alternateUrls,
            'canonicalUrl' => $canonicalUrl,
        ]);
    }
}
