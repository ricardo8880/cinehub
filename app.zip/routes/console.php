<?php

use Illuminate\Foundation\Inspiring;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Schedule;

Artisan::command('inspire', function () {
    $this->comment(Inspiring::quote());
})->purpose('Display an inspiring quote');

if (config('site.backup_enabled')) {
    Schedule::command('mrrcine:backup')->dailyAt('03:30')->withoutOverlapping();
}
